//
//  ViewModel.swift
//  Unsplash
//
//  Created by Илья Белкин on 29.09.2022.
//

import Foundation

// добавь необходимые поля в entity модели и здесь (одинаковые)

struct ViewModel {
    let id: String?
    let likes: Int?
    var imageURL: String?

    
    init(model: Empty) {
        self.id = model.id
        self.likes = model.likes
        self.imageURL = model.urls.thumb
    }
}
