//
//  TabBarController.swift
//  Unsplash
//
//  Created by Илья Белкин on 29.09.2022.
//

import UIKit

class TabBarController: UITabBarController, UITabBarControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        delegate = self
        setupBar()
    }
    
    func setupBar() {
            let photos = createNavigationContoller(viewContoller: PhotoCollectionViewController(), itemName: "Photos", itemImage: "photo")
            let favorites = createNavigationContoller(viewContoller: FavoritesViewController(), itemName: "Favorites", itemImage: "heart")
            viewControllers = [photos, favorites]
        }

        func createNavigationContoller(viewContoller: UIViewController, itemName: String, itemImage: String) -> UINavigationController {
            let item = UITabBarItem(title: itemName, image: UIImage(systemName: itemImage), selectedImage: UIImage(systemName: itemImage))
            let navigationContoller = UINavigationController(rootViewController: viewContoller)
            navigationContoller.tabBarItem = item
            return navigationContoller
        }

}
