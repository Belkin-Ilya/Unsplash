//
//  PhotoCollectionViewController.swift
//  Unsplash
//
//  Created by Илья Белкин on 29.09.2022.
//

import UIKit

class PhotoCollectionViewController: UIViewController {
    // MARK: - Privat Properties
    
    private var viewModels: [ViewModel] = []
    private lazy var searchСontroller = UISearchController()
    
    private var photoCollectionView: PhotoCollectionView? {
        guard isViewLoaded else { return nil }
        return view as? PhotoCollectionView
    }
    
    // MARK: - Lifecycle
    
    override func loadView() {
        super.loadView()
        let view = PhotoCollectionView()
        view.customDelegate = self
        self.view = view
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Photos"
        navigationController?.navigationBar.prefersLargeTitles = true
        fetchData()
    }
    
    // MARK: - Privat Methods
    
    private func configureSearchController() {
        searchСontroller.searchBar.placeholder = "Search"
        searchСontroller.automaticallyShowsCancelButton = true
        searchСontroller.searchBar.setImage(UIImage(systemName: "magnifyingglass"), for: .search, state: .normal)
    }
    
    private func fetchData() {
        NetworkManager.shared.fetchData(of: [Empty].self) { [weak self] result in
            guard let self = self else { return }
            switch result {
            case .success(let data):
                let viewModel = data.map ({ ViewModel(model: $0)})
                self.viewModels = viewModel
                DispatchQueue.main.async {
                    guard let photoCollectionView = self.view as? PhotoCollectionView else { return }
                    photoCollectionView.collectionView.reloadData()
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
}

// MARK: - PhotoCollectionViewDelegate

extension PhotoCollectionViewController: PhotoCollectionViewDelegate {
    func photoCollectionViewGetViewModelsCount(_ photoCollectionView: PhotoCollectionView) -> Int? {
        return viewModels.count
    }
    
    func photoCollectionViewGetPhotoModel(_ photoCollectionView: PhotoCollectionView, getPhotoViewModelAt index: Int) -> ViewModel? {
        return viewModels[index]
    }
    
//    func photoCollectionViewDidSelect(photoCollectionView: PhotoCollectionView, didselectPhotoAtIndex index: Int) {
//        <#code#>
//    }
    
}
