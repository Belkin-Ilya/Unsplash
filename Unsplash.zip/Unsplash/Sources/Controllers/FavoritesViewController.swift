//
//  ViewController.swift
//  Unsplash
//
//  Created by Илья Белкин on 29.09.2022.
//

import UIKit

class FavoritesViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .white
        navigationController?.navigationBar.prefersLargeTitles = true
    }
}

