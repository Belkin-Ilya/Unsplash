//
//  UIImage+Icons.swift
//  Unsplash
//
//  Created by Илья Белкин on 30.09.2022.
//

import UIKit

extension UIImage {
    convenience init?(image: Icon) {
        self.init(named: image.rawValue)
    }

    enum Icon: String, CaseIterable {
        case reset
        case plusButton
        case colorAndSizeSeleсting
        case keyboard
        case textFormatting
        case selectedFont
        case boldText
        case italicText
        case strikethroughText
        case underlineText
        case leftAlignment
        case centerAlignment
        case rightAlignment
        case leftIndent
        case rightIndent
        case plus
        case rectangle
        case backArrow
        case xMark
        case settings
        case paintpalette
    }
}

