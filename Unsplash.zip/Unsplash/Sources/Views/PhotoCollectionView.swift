//
//  PhotoCollection.swift
//  Unsplash
//
//  Created by Илья Белкин on 29.09.2022.
//

import UIKit

// для передачи используй делегаты

protocol PhotoCollectionViewDelegate: AnyObject {
    func photoCollectionViewGetViewModelsCount(_ photoCollectionView: PhotoCollectionView) -> Int?
    func photoCollectionViewGetPhotoModel(_ photoCollectionView: PhotoCollectionView, getPhotoViewModelAt index: Int) -> ViewModel?
    //func photoCollectionViewDidSelect(photoCollectionView: PhotoCollectionView, didselectPhotoAtIndex index: Int)
    
    // соблюдай нейминг как у меня (читай гайды)
    // передаешь сюда модель по индексу и из модели заполняешь ячейки
}

class PhotoCollectionView: UIView {
    // MARK: - Public Properties
    weak var customDelegate: PhotoCollectionViewDelegate?
    
    private func makeCollectionViewLayout() -> UICollectionViewFlowLayout {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical

        return layout
    }
    
//    создавай элементы везде одинаково или через статик методы как в ячейке или так
     lazy var collectionView: UICollectionView = {
        let layout = makeCollectionViewLayout()
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.register(PhotoCollectionViewCell.self, forCellWithReuseIdentifier: PhotoCollectionViewCell.id)
        
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        return collectionView
    }()
    
    // MARK: - Init
    
    init() {
        super.init(frame: .zero)
        configureView()
        setupHierarchy()
        activateCollectionViewConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Privat Methods
    
    private func configureView() {
        backgroundColor = .white
    }
    
    private func setupHierarchy() {
        addSubview(collectionView)
    }
    
    private func activateCollectionViewConstraints() {
        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: topAnchor),
            collectionView.leadingAnchor.constraint(equalTo: leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
    }
}

// MARK: - UICollectionViewDataSource

extension PhotoCollectionView: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return customDelegate?.photoCollectionViewGetViewModelsCount(self) ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cellID = PhotoCollectionViewCell.id
        guard
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellID, for: indexPath) as? PhotoCollectionViewCell,
            let viewModel = customDelegate?.photoCollectionViewGetPhotoModel(self, getPhotoViewModelAt: indexPath.row)
        else {
            return UICollectionViewCell()
        }
        
        cell.configure(with: viewModel)
        
        return cell
    }
}

// MARK: - UICollectionViewDelegate

extension PhotoCollectionView: UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(
            width:  (collectionView.frame.size.width / 2.12) - 5,
            height: (collectionView.frame.size.height / 4) - 5
        )
    }
}
